// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getLocationRepositoryHash() =>
    r'a2fe8f253b24c1c6cd8cc00825c0fdf2938a1073';

/// See also [getLocationRepository].
@ProviderFor(getLocationRepository)
final getLocationRepositoryProvider =
    AutoDisposeProvider<LocationRepository>.internal(
  getLocationRepository,
  name: r'getLocationRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getLocationRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef GetLocationRepositoryRef = AutoDisposeProviderRef<LocationRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
