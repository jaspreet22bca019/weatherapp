const String imgBaseUrl = 'http://openweathermap.org/img/wn/';
const String apiKey = '126a1bfa19c59da5f3fcb88d289614c5';
const String appBaseUrl = 'https://api.openweathermap.org/data/2.5';
